import pandas as pd
import re
import sqlite3

from flask import Flask, request, jsonify
from flasgger import Swagger, LazyString, LazyJSONEncoder
from flasgger import swag_from

app = Flask(__name__)
app.json_encoder = LazyJSONEncoder
swagger_template = dict(
info = {
    'title': LazyString(lambda: 'API Documentation for Data Cleansing'),
    'version': LazyString(lambda: '1.0.0'),
    'description': LazyString(lambda: 'Dokumentasi API untuk Data Cleansing'),
    },
    host = LazyString(lambda: request.host)
)
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'docs',
            "route": '/docs.json',
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/"
}
swagger = Swagger(app, template=swagger_template,             
                  config=swagger_config)


def proses(input_teks):
    input_teks = re.sub(r"http[s]?\://\S+","",input_teks)
    input_teks = re.sub(r"[.,@#!?]", "",input_teks)
    input_teks = re.sub(r"\n", "",input_teks)
    input_teks = re.sub(r"[0-9]", "",input_teks)
    return input_teks

def database_text(kolom1,kolom2):
    conn = sqlite3.connect("data_cleansing.db")
    cursor = conn.cursor()

    cursor.execute("""CREATE TABLE IF NOT EXISTS hasil_cleansingdata_input (teks, result)""")
    cursor.execute("""INSERT INTO hasil_cleansingdata_input (teks, result)VALUES (?,?)""",(kolom1,kolom2))

    conn.commit()
    cursor.close()
    conn.close()

def database_csv(data):
    conn = sqlite3.connect("data_cleansing.db")
    cursor = conn.cursor()

    cursor.execute("""CREATE TABLE IF NOT EXISTS hasil_cleansingdata_csv (teks, hasil)""")
    data.to_sql('hasil_cleansingdata_csv', conn, if_exists = 'append', index = False)

@swag_from("docs/form.yaml", methods=['POST'])
@app.route('/form', methods=['POST'])
def text_processing():

    txt = request.form.get('input')
    
    result = proses(txt)

    database_text(txt,result)

    json_response = {
            'status_code': 200,
            'description': "sudah dilakukan data cleansing dan ditambahkan ke database",
            'result': result,
            'input': txt,
        }

    response_data = jsonify(json_response)
    return response_data

@swag_from("docs/file.yaml", methods=['POST'])
@app.route('/file', methods=['POST'])
def text_processing_file():

    file = request.files['file']

    df = pd.read_csv(file,header=0)

    df['hasil'] = df.apply(lambda row : proses(row['teks']), axis = 1)
    
    result = df.hasil.to_list()

    database_csv(df)

    json_response = {
        'status_code': 200,
        'description': "sudah dilakukan data cleansing dan ditambahkan ke database",
        'data': result,
    }
    response_data = jsonify(json_response)
    return response_data

if __name__ == '__main__':
    app.run(debug=True)
    